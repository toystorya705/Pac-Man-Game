<?php

include('common.php'); //Linking File
outputHead("Home"); // Calling Header Portion
outputNavigation("Home"); // Calling Navigation Bar
?>

<div class="home">

    <a href="PlayGame.php"><!--Button link-->
        <span></span><!--Transition Line-->
        <span></span><!--Transition Line-->
        <span></span><!--Transition Line-->
        <span></span><!--Transition Line-->
        Play Game</a><!--Transition Line-->
</div>


<?php
outputFooter(); // Calling Footer

?>