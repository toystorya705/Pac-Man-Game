<?php

include('common.php'); //Linking File
outputHead("Contact Us"); // Calling Header Portion
outputNavigation("Contact Us"); // Calling Navigation Bar
?>

<div class="contactus">
    <label>Contact us </label>
    <!--Label-->
    <p class="para1">Email ID: PackMan@gmail.com</p>
    <!--Paragraph-->
    <p class="para2">Phone No. +44 1234567890</p>
    <!--Paragraph-->
    <p class="para3">Address: Barnet, NW4 4BT</p>
    <!--Paragraph-->

</div>


<?php
outputFooter(); // Calling Footer

?>